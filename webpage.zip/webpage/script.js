// Add interactivity
document.addEventListener("DOMContentLoaded", () => {
    alert("Welcome to the webpage!");
});
